def hello():
    print("hello")